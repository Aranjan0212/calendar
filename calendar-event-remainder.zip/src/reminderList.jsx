import React, { memo } from "react";

const ReminderList = ({ state, dispatch }) => {
  return (
    <div className="mt-4">
      {state?.map((value) => (
        <div key={value.id}>
          <p>{value.date}</p>
          <p>{value.reminderSubject}</p>
          <p>{value.reminderDesc}</p>
          <p>{value.repeatedFrequency?.toString()}</p>
          <div className="d-flex gap-3">
            {value.isReminderEnabled ? (
              <button
                className="btn btn-secondary"
                onClick={() =>
                  dispatch({
                    type: "DISABLE_REMINDER",
                    payload: { value },
                  })
                }
              >
                Disable
              </button>
            ) : (
              <button
                className="btn btn-info"
                onClick={() =>
                  dispatch({
                    type: "ENABLE_REMINDER",
                    payload: { value },
                  })
                }
              >
                Enable
              </button>
            )}
            <button
              className="btn btn-light"
              onClick={() =>
                dispatch({
                  type: "EDIT_REMINDER",
                  payload: { value: value, reminderDesc: "shjdkjfhjkhdkhdk" },
                })
              }
            >
              Edit
            </button>
            <button
              className="btn btn-danger"
              onClick={() =>
                dispatch({ type: "DELETE_REMINDER", payload: { value } })
              }
            >
              Delete
            </button>
          </div>
        </div>
      ))}
    </div>
  );
};

export default memo(ReminderList);
