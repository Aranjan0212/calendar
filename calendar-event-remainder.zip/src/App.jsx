import { useMemo, useReducer, useState } from "react";
import ReminderList from "./reminderList";

const repeatDays = [2, 3, 5, 7];
const dropDownData = [
  { id: "idx-1", option: "food", value: "Food Time" },
  { id: "idx-2", option: "standup", value: "Standup Call" },
  { id: "idx-3", option: "checkout", value: "Checkout Call" },
];

function reducer(state, action) {
  console.log(action);
  const index = state.indexOf(action.payload.value);

  switch (action.type) {
    case "ADD_REMINDER":
      return [
        ...state,
        {
          id: "idx-" + state.length + 1,
          date: action.payload?.date,
          email: action.payload?.email,
          mobileNumber: action.payload?.mobileNumber,
          status: "ENABLED",
          isReminderEnabled: true,
          reminderSubject: action.payload?.reminderSubject,
          reminderDesc: action.payload?.reminderDesc,
          repeatedFrequency: action.payload?.repeatedFrequency,
        },
      ];
    case "DELETE_REMINDER":
      if (index > -1) {
        state.splice(index, 1);
      }
      console.log(state);
      return [...state];
    case "EDIT_REMINDER":
      state[index] = {
        id: state[index]?.id,
        date: action.payload?.date || state[index]?.date,
        email: action.payload?.email || state[index]?.email,
        mobileNumber:
          action.payload?.mobileNumber || state[index]?.mobileNumber,
        status: action.payload?.status || state[index]?.status,
        isReminderEnabled:
          action.payload?.isReminderEnabled || state[index]?.isReminderEnabled,
        reminderSubject:
          action.payload?.reminderSubject || state[index]?.reminderSubject,
        reminderDesc:
          action.payload?.reminderDesc || state[index]?.reminderDesc,
        repeatedFrequency:
          action.payload?.repeatedFrequency || state[index]?.repeatedFrequency,
      };
      return [...state];
    case "ENABLE_REMINDER":
      state[index].isReminderEnabled = true;
      return [...state];
    case "DISABLE_REMINDER":
      state[index].isReminderEnabled = false;
      return [...state];
    default:
      break;
  }

  throw Error("Unknown action.");
}

function App() {
  const [state, dispatch] = useReducer(reducer, []);
  const [formValue, setFormValue] = useState({});
  const [repeatDuration, setRepeatDuration] = useState([]);

  const isInputValidated = useMemo(() => {
    if (
      formValue &&
      formValue.date &&
      formValue.reminderSubject &&
      formValue.reminderDesc &&
      (formValue.email || formValue.mobileNumber)
    ) {
      return false;
    }
    return true;
  }, [formValue]);

  const handleSubmit = () => {
    dispatch({
      type: "ADD_REMINDER",
      payload: {
        email: formValue.email,
        mobileNumber: formValue.mobileNumber,
        reminderSubject: formValue.reminderSubject,
        reminderDesc: formValue.reminderDesc,
        repeatedFrequency: repeatDuration,
        date: formValue.date,
      },
    });
    alert("Reminder Added SuccessFully");
    setFormValue({});
    setRepeatDuration({});
  };
  return (
    <div style={{ margin: 50 }}>
      <form method="post">
        <div style={{ marginBottom: 16 }}>
          <label
            htmlFor="datePicker"
            style={{ marginRight: 16, width: 150, display: "inline-block" }}
          >
            Select Date
          </label>
          <input
            type="date"
            name="date"
            id="datePicker"
            required
            value={formValue?.date || ""}
            onChange={(event) =>
              setFormValue((data) => {
                return {
                  ...data,
                  date: event.target.value,
                };
              })
            }
          />
        </div>
        <div style={{ marginBottom: 16 }}>
          <label
            htmlFor="subjectPicker"
            style={{ marginRight: 16, width: 150, display: "inline-block" }}
          >
            Select Subject
          </label>
          <select
            id="subjectPicker"
            name="subjectPicker"
            style={{ width: 120 }}
            required
            value={formValue?.reminderSubject || "subject"}
            onChange={(event) =>
              setFormValue((data) => {
                return {
                  ...data,
                  reminderSubject: event.target.value,
                };
              })
            }
          >
            <option value="subject" disabled>
              Select Subject
            </option>
            {dropDownData.map(({ id, value, option }) => (
              <option value={value} key={id}>
                {option}
              </option>
            ))}
          </select>
        </div>
        <div style={{ marginBottom: 16 }}>
          <label
            htmlFor="description"
            style={{ marginRight: 16, width: 150, display: "inline-block" }}
          >
            Enter Description
          </label>
          <textarea
            id="description"
            name="description"
            value={formValue?.reminderDesc || ""}
            onChange={(event) =>
              setFormValue((data) => {
                return {
                  ...data,
                  reminderDesc: event.target.value,
                };
              })
            }
          />
        </div>
        <div style={{ marginBottom: 16 }}>
          <label
            htmlFor="email"
            style={{ marginRight: 16, width: 150, display: "inline-block" }}
          >
            Enter mail
          </label>
          <input
            type="email"
            id="email"
            name="email"
            value={formValue?.email || ""}
            onChange={(event) =>
              setFormValue((data) => {
                return {
                  ...data,
                  email: event.target.value,
                };
              })
            }
          />
        </div>
        <div style={{ marginBottom: 16 }}>
          <label
            htmlFor="contactNo"
            style={{ marginRight: 16, width: 150, display: "inline-block" }}
          >
            Enter Mobile Number
          </label>
          <input
            type="text"
            name="contactNo"
            id="contactNo"
            maxLength={10}
            value={formValue?.mobileNumber || ""}
            onChange={(event) =>
              setFormValue((data) => {
                return {
                  ...data,
                  mobileNumber: event.target.value,
                };
              })
            }
          />
        </div>
        <div
          style={{ marginBottom: 16, display: "flex", alignItems: "center" }}
        >
          <p
            htmlFor="days"
            style={{ marginRight: 16, width: 150, display: "inline-block" }}
          >
            Repeat Duration
          </p>
          <div style={{ display: "flex", gap: 20 }}>
            {repeatDays.map((value) => (
              <div key={value}>
                <input
                  type="checkbox"
                  id={"days-" + value}
                  key={value}
                  value={value}
                  onChange={(event) =>
                    setRepeatDuration((data) => {
                      return data.length && data?.includes(event.target.value)
                        ? data?.filter((value) => value !== event.target.value)
                        : [...data, event.target.value];
                    })
                  }
                />
                <label htmlFor={"days-" + value} className="ms-1">
                  {value} Days
                </label>
              </div>
            ))}
          </div>
        </div>
      </form>

      <button type="submit" onClick={handleSubmit} disabled={isInputValidated}>
        Add Reminder
      </button>
      <ReminderList state={state} dispatch={dispatch} />
    </div>
  );
}

export default App;
